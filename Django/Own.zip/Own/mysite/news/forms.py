from django import forms

from .models import Category
from .models import News

class NewsForm(forms.ModelForm):
    # title = forms.CharField(max_length = 150, label = 'Название ',widget=forms.TextInput(
    #     attrs={"class":'form-control'}
    # ))
    # content = forms.CharField(label = 'Текст ', required = False,widget = forms.Textarea(
    #     attrs={"class":'form-control','rows':5}
    # ))
    # is_published = forms.BooleanField(label = 'Опубликовано? ',initial = True)
    # category = forms.ModelChoiceField(empty_label = 'Выберите категорию',queryset = Category.objects.all(), label='Категория ',widget=forms.Select(
    #     attrs={"class":'form-control'}
    # ))
    
    # Для Формы связанной с моделью
    class Meta: # Тут опишем как будет выглядеть наша Форма
        model = News  # Указываем с какой моделью будет связана наша форма
        #fields = '__all__' # Перечисляем поля, которые хотим видеть в данной форме. Если пишем __all__ то значит все поля
        fields = ['title','content','is_published','category']
        widgets = {
            'title':forms.TextInput(attrs = {'class':'form-control'}),
            'content':forms.Textarea(attrs = {'class':'form-control','rows':5}),
            'category':forms.Select(attrs = {'class':'form-control'})
        }
