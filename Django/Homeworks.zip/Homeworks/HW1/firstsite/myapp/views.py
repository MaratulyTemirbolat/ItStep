from django.http import HttpResponse

def index(request):
    return HttpResponse("<h1>Ура! Первая страничка хоть как-то готова!</h1>")