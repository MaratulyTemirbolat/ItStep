from django.contrib import admin

from .models import *

class RoleAdmin(admin.ModelAdmin):
    list_display = ('name',)

class UserAdmin(admin.ModelAdmin):
    list_display = ('name','login','user_password','email','role')
    list_display_links = ('name','login')
    list_editable = ('email','role')
    list_filter = ('role',)
    search_fields = ('name','login','email')

class AudentificationAuditAdmin(admin.ModelAdmin):
    list_display = ('user','date_enter','time_duration')
    list_display_links = ('user',)
    list_filter = ('date_enter',)

class ResponseAdmin(admin.ModelAdmin):
    list_display = ('user','created_at','description','topic')
    list_filter = ('topic','created_at')
    list_display_links = ('description','topic')

class TopicAdmin(admin.ModelAdmin):
    list_display = ('name','section','description','owner')
    list_display_links = ('name','description')
    list_filter = ('section',)
    search_fields = ('name',)

admin.site.register(Right)
admin.site.register(Role,RoleAdmin)
admin.site.register(User,UserAdmin)
admin.site.register(AudentificationAudit,AudentificationAuditAdmin)
admin.site.register(Response,ResponseAdmin)
admin.site.register(Topic,TopicAdmin)
admin.site.register(Section)
