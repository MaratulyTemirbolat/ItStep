from django.db import models

class Right(models.Model):
    name = models.CharField(max_length = 150,unique = True,db_index = True,\
        verbose_name = 'Право')
    
    class Meta:
        verbose_name_plural = 'Права'
        verbose_name = 'Право'
        ordering = ['name']

    def __str__(self):
        return self.name

class Role(models.Model):
    name = models.CharField(max_length = 100,unique = True,db_index = True,\
        verbose_name = 'Роль')
    
    rigths = models.ManyToManyField(Right)
    
    class Meta:
        verbose_name_plural = 'Роли'
        verbose_name = 'Роль'
        ordering = ['name']

    def __str__(self):
        return self.name

class User(models.Model):
    name = models.CharField(max_length = 150,unique = True,db_index = True,\
         verbose_name = 'Имя')
    login = models.CharField(max_length = 150,unique = True,db_index = True,\
        verbose_name = 'Логин')
    user_password = models.CharField(max_length = 150, verbose_name = 'Пароль')
    email = models.CharField(max_length = 150,unique = True, \
        verbose_name = 'Почта')
    role = models.ForeignKey(Role,on_delete = models.PROTECT,\
        verbose_name = 'Роль')

    class Meta:
        verbose_name_plural = 'Пользователи'
        verbose_name = 'Пользователь'
        ordering = ['name']
    
    def __str__(self):
        return self.name + ' (' + self.login + ')'

class AudentificationAudit(models.Model):
    user = models.ForeignKey('User',on_delete = models.PROTECT,\
        verbose_name = 'Пользователь')
    date_enter = models.DateField(auto_now_add = True,verbose_name = 'Дата посещения')
    time_duration = models.TimeField(null = True, blank = True,\
        verbose_name = 'Продолжительность сеанса')
    
    class Meta:
        verbose_name_plural = 'Аудит авторизаций'
        verbose_name = 'Аудит авторизаций'

class Response(models.Model):
    user = models.ForeignKey(User,on_delete = models.DO_NOTHING,\
        verbose_name = 'Пользователь')
    created_at = models.DateTimeField(auto_now_add = True,\
        verbose_name = 'Дата создания')
    description = models.TextField(verbose_name = 'Контент')
    topic = models.ForeignKey('Topic',on_delete = models.PROTECT,\
        verbose_name = 'Тема')
    
    class Meta:
        verbose_name = 'Ответ'
        verbose_name_plural = 'Ответы'
        ordering = ['topic']

class Topic(models.Model):
    name = models.CharField(max_length = 200,verbose_name = 'Название')
    section = models.ForeignKey('Section',on_delete = models.PROTECT,\
        verbose_name = 'Секция')
    description = models.TextField(verbose_name = 'Описание')
    owner = models.OneToOneField(User,on_delete = models.PROTECT,\
        verbose_name = 'Спросил')
    
    class Meta:
        verbose_name_plural = 'Темы'
        verbose_name = 'Тема'
        ordering = ['name']

    def __str__(self):
        return self.name

class Section(models.Model):
    name = models.CharField(max_length = 150,unique = True,\
        db_index = True,verbose_name = 'Наименование секции')
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name_plural = 'Секции'
        verbose_name = 'Секция'
        ordering = ['name']