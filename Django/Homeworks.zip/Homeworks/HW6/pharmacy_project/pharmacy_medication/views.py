from .models import Medication
from .models import Category
from django.shortcuts import render

from django.views.generic.edit import CreateView
from .forms import MedicationForm

from django.urls import reverse_lazy

def index(request):
    medications = Medication.objects.all()
    categories = Category.objects.all()
    context = {
        'medications':medications,
        'categories':categories
    }
    return render(request,'pharmacy_medication/index.html',context)

def get_by_category_id(request,category_id):
    medications = Medication.objects.filter(category = category_id)
    categories = Category.objects.all()
    cur_category = Category.objects.get(pk = category_id)
    context = {
        'categories':categories,
        'medications':medications,
        'cur_category':cur_category
    }
    return render(request,'pharmacy_medication/get_by_category_id.html',context)

class MedicationCreateView(CreateView):  # Создаем контроллер-класс для вывода формы
    template_name = 'pharmacy_medication/add_medication.html' # Путь к шаблону формы 
    form_class = MedicationForm  # Ссылка на класс формы, связанной с моделью
    success_url = reverse_lazy('index')  # URL для перенаправления при успешном сохранении данных формы

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs) # Подготовит контекст формы и вернет его
        context['categories'] = Category.objects.all()  # Добавляем контекст списка категорий
        return context