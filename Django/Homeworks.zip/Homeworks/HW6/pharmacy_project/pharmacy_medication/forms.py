from django.forms import ModelForm
from .models import Medication

class MedicationForm(ModelForm):  # Создаем форму, связанную с моделью
    class Meta:
        model = Medication # Указываем с какой моделью связана данная форма
        fields = ('name','description','price','quantity','category') # Указываем, какие поля будут присутствовать в форме
