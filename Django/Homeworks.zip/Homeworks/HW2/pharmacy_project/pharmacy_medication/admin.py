from django.contrib import admin
from django.http.request import MediaType

from .models import Medication

# Register your models here.

class MedicationAdmin(admin.ModelAdmin):
    list_display = ['name','description','price','quantity']
    list_display_links = ['name','description']
    search_fields = ['name','description']

admin.site.register(Medication,MedicationAdmin)