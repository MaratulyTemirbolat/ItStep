from django.db import models
from django.db.models.expressions import F

class Medication(models.Model):
    name = models.CharField(max_length = 100,null = False,unique = True,verbose_name = 'Название')
    description = models.TextField(null = False,blank = True,verbose_name = 'Описание')
    price = models.FloatField(null = False, default = 0.0,verbose_name = 'Цена')
    quantity = models.IntegerField(null = False, default = 0, verbose_name = 'Количество')

    class Meta:
        verbose_name_plural = 'Лекарства'
        verbose_name = 'Лекарство'
        ordering = ['-price']