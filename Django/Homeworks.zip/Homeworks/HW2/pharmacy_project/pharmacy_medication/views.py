from .models import Medication
from django.shortcuts import render

def index(request):
    medications = Medication.objects.all()
    return render(request,'pharmacy_medication/index.html',{'medications':medications})