from .models import Medication
from .models import Category
from django.shortcuts import render

def index(request):
    medications = Medication.objects.all()
    categories = Category.objects.all()
    context = {
        'medications':medications,
        'categories':categories
    }
    return render(request,'pharmacy_medication/index.html',context)

def get_by_category_id(request,category_id):
    medications = Medication.objects.filter(category = category_id)
    categories = Category.objects.all()
    cur_category = Category.objects.get(pk = category_id)
    context = {
        'categories':categories,
        'medications':medications,
        'cur_category':cur_category
    }
    return render(request,'pharmacy_medication/get_by_category_id.html',context)