from django.contrib import admin


from .models import Group
from .models import Student
from .models import Subject
from .models import Room
from .models import Teacher
from .models import Schedule
from .models import StudentMark


class StudentAdmin(admin.ModelAdmin):
    list_display = ['individual_identification_number','full_name','group','student_status']

class TeacherAdmin(admin.ModelAdmin):
    list_display = ['full_name','status']

class StudentMarkAdmin(admin.ModelAdmin):
    list_display = ['student','schedule','mark']

admin.site.register(Group)
admin.site.register(Student,StudentAdmin)
admin.site.register(Subject)
admin.site.register(Room)
admin.site.register(Teacher,TeacherAdmin)
admin.site.register(Schedule)
admin.site.register(StudentMark,StudentMarkAdmin)