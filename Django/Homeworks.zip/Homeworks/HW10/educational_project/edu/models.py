from datetime import date
from django.db import models
from django.core.exceptions import ValidationError
from django.core import validators

from django.utils import timezone
import re

class Group(models.Model):
    name = models.CharField(max_length = 100,unique = True,null = False,\
        blank = True,verbose_name = 'Наименование')

    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name_plural = 'Группы'
        verbose_name = 'Группа'
        ordering = ['name']

class Student(models.Model):
    STATUSES = (
        ('active','Активен'),
        ('academic leave','Академический отпуск'),
        ('expelled','Отчислен')
    )
    individual_identification_number = models.CharField(max_length = 12, null = False,\
         unique = True, blank = False, verbose_name = 'ИИН',\
             validators = [validators.RegexValidator(regex = '^\d{12}$',\
                 message = 'ИИН должен содержать только 12 цифр',code = 'iin_error')])
    full_name = models.CharField(max_length = 150, null = False,\
        blank = False,verbose_name = 'ФИО')
    group = models.ForeignKey(Group,on_delete = models.PROTECT,\
        null = False,blank = False,verbose_name = 'Группа')
    student_status = models.CharField(max_length = 25,choices = STATUSES,\
        default = 'active',verbose_name = 'Статус студента')

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name_plural = 'Студенты'
        verbose_name = 'Студент'
        ordering = ['group']

class Subject(models.Model):
    name = models.CharField(max_length = 100,unique = True,null = False,\
        blank = True,verbose_name = 'Название')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = 'Дисциплины'
        verbose_name = 'Дисциплина'
    
class Room(models.Model):
    FLOORS = (
        (1,'1'),
        (2,'2'),
        (3,'3'),
    )
    name = models.CharField(max_length = 100,blank = True,null = False,\
        verbose_name = 'Название')
    floor = models.IntegerField(choices = FLOORS,default = 1,\
        verbose_name = 'Этаж')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = 'Кабинеты'
        verbose_name = 'Кабинет'

class Teacher(models.Model):
    STATUSES = (
        ('active','Действующий'),
        ('inactive','Не действующий')
    )
    full_name = models.CharField(max_length = 150,null = False,\
        blank = False,verbose_name = 'ФИО')  
    status = models.CharField(max_length = 10,choices = STATUSES,\
        default = 'active',verbose_name = 'Статус')
    
    def __str__(self):
        return self.full_name
    
    class Meta:
        verbose_name_plural = 'Преподаватели'
        verbose_name = 'Преподаватель'
        ordering = ['status']

def schedule_date_time_validation(date_time):
    now = timezone.now()
    if(date_time < now):
        raise ValidationError('Дата %(date_time)s не может быть назначена в прошлом',
        code = 'date_time_low_limit',params ={'date_time':date_time})

def schedule_date_time_reg_validation(date_time):
    schedule_date_time = str(date_time).split(' ')
    schedule_date_time[1] = schedule_date_time[1].replace('+06:00','')
    schedule_date_time = schedule_date_time[0] + ' ' + schedule_date_time[1]
    reg_expr = '^[0-9]{4}-[0-1][0-9]-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$'
    result_ex = re.fullmatch(reg_expr,schedule_date_time)
    if(result_ex == False):
        raise ValidationError('%(my_date_time)s не соответсвует шаблону ГГГГ-ММ-ДД ЧЧ:ММ:СС ',
        code = 'date_time_format',params={'my_date_time':schedule_date_time})

class Schedule(models.Model):
    conductance_time = models.DateTimeField(db_index = True,\
        verbose_name = 'Дата проведения',
        validators = [schedule_date_time_validation,schedule_date_time_reg_validation])
    group = models.ForeignKey(Group,on_delete = models.PROTECT,null = False,\
        blank = False,verbose_name = 'Группа')
    teacher = models.ForeignKey(Teacher, on_delete = models.PROTECT,\
        null = False, blank = False, verbose_name = 'Преподаватель')
    subject = models.ForeignKey(Subject, on_delete = models.PROTECT,\
        null = False, blank = False, verbose_name = 'Дисциплина')
    room = models.ForeignKey(Room,on_delete = models.PROTECT,\
        null = False, blank = False, verbose_name = 'Кабинет')

    def __str__(self):
        return  str(self.subject) + '\n' + str(self.conductance_time) + '\n' + str(self.group)

    class Meta:
        verbose_name_plural = 'Расписания'
        verbose_name = 'Расписание'
        ordering = ['conductance_time']

def validate_mark_limits(mark):
    MIN_MARK = 1
    MAX_MARK = 10
    if(mark < MIN_MARK or mark > MAX_MARK):
        raise ValidationError('Оценка %(mark)s не находится в пределах от %(MIN_MARK)s до %(MAX_MARK)s',
        code = 'mark_limit',params = {'mark':mark,'MIN_MARK':MIN_MARK,'MAX_MARK':MAX_MARK})

class StudentMark(models.Model):
    student = models.ForeignKey(Student, on_delete = models.PROTECT,null = False,\
        blank = False, verbose_name = 'Студент')
    schedule = models.ForeignKey(Schedule,on_delete = models.RESTRICT, null = False,\
        blank = False, verbose_name = 'Урок')
    mark = models.IntegerField(null = False, blank = False, verbose_name = 'Оценка',\
        validators = [validate_mark_limits])
    
    class Meta:
        verbose_name_plural = 'Оценки студентов'
