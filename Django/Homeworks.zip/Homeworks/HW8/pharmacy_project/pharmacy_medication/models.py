from django.db import models
from django.db.models.deletion import RESTRICT
from django.db.models.expressions import F

class Category(models.Model):
    name = models.CharField(max_length = 50,unique = True,verbose_name = 'Название')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = 'Категории'
        verbose_name = 'Категория'
        ordering = ['name']

class Medication(models.Model):
    class VacationCondition(models.TextChoices):
        WITH_PRESCRIPTION = 'with_prescription','По рецепту'
        NO_PRESCRIPTION = 'no_prescription','Без рецепта'
    
    name = models.CharField(max_length = 100,null = False,unique = True,\
        verbose_name = 'Название')
    description = models.TextField(null = False,blank = True,\
        verbose_name = 'Описание')
    price = models.FloatField(null = False, default = 0.0,verbose_name = 'Цена')
    quantity = models.IntegerField(null = False, default = 0, \
        verbose_name = 'Количество')
    category = models.ForeignKey(Category,null = True,on_delete = models.RESTRICT,\
        verbose_name = 'Категория товара')
    vacation_condition = models.CharField(max_length = 40,\
        choices = VacationCondition.choices,default = VacationCondition.NO_PRESCRIPTION,\
            blank = False,null = False,verbose_name = 'Условие отпуска из аптеки')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = 'Лекарства'
        verbose_name = 'Лекарство'
        ordering = ['-price']