from django.contrib import admin
from django.http.request import MediaType

from .models import Medication
from .models import Category

class MedicationAdmin(admin.ModelAdmin):
    list_display = ['name','description','price','quantity','category','vacation_condition']
    list_display_links = ['name','description']
    search_fields = ['name','description','category']


admin.site.register(Medication,MedicationAdmin)
admin.site.register(Category)