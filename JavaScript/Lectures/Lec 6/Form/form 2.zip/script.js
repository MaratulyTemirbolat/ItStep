let areaInput = document.getElementById("area"),
floorSelect = document.getElementById("floor"),
resultDiv = document.getElementById("result")

function calculate(){
    resultDiv.textContent = areaInput.value * floorSelect.value
}
floorSelect.onchange = calculate
areaInput.oninput = calculate