// console.log(document.forms)
// console.log(document.forms[0])
// console.log(document.forms.myform)

let form = document.forms[0]

console.log(form)
console.log(form.elements)
console.log(form.elements[0])
console.log(form.elements[0].form)

form.onsubmit = function(event){
    event.preventDefault()
    console.log("submit")
    // form.submit()    
}

// let div = document.querySelector(".main")
// console.log(div.className)
// console.log(div.classList)
// div.className = "footer"
// div.classList.add("footer")
// div.classList.remove("main")
// div.classList.toggle("my")

let inp = form.elements[0]

inp.onfocus = function(){
    console.log("focus")
}
inp.onblur = function(){
    console.log("blur")
}
// inp.oninput = function(){
//     console.log(inp.value)
// }
inp.onchange = function(){
    console.log(inp.value)
}

let radios = document.querySelectorAll('input[type="radio"]')

let btn = document.querySelector("button")

// btn.onclick = function(){
//     for (let item of radios){
//         if(item.checked){
//             console.log(item.value)
//             break;
//         }
//     }
// }

// btn.onclick = function(){
//     let selected = document.querySelector('input[type="radio"]:checked')

//     console.log(selected.value)
// }

// btn.onclick = function(){
//     console.log(form.elements.r.value)
// }

let select = form.elements[5]

select.onchange = function(){
    console.log(select.value)
    console.log(select.selectedIndex)
}
console.log(select.options)

let option = new Option("four", "4")
select.add(option)